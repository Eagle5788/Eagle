<?php

$token = 7828528800:AAGlOY7One7mg7iXz5floHu5BUINGVCYM8kYQKukrGr5gTUNIt3ZHRuPTEo";
$data = [
    'text' => $msg,
    'chat_id' => '7587004138'
];

?>